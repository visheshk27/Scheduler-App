package com.example.personalcalender;

import java.util.Date;

public class Koushik {
    String str;
    Date date;

    public Koushik() {
        str="";
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }
}
